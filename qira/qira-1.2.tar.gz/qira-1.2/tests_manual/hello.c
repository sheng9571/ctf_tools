#include <stdio.h>
int main() { write(0, "hello world\n", 12); return 0; }

