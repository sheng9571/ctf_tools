int main(int argc, char *argv[]) {
  switch(argc) {
    case 1:
      printf("1 args\n");
      break;
    case 2:
      printf("2 args\n");
      break;
    case 3:
      printf("3 args\n");
      break;
    case 10:
      printf("10 args\n");
      break;
    case 47:
      printf("47 args\n");
      break;
  }
  return 0;
}

