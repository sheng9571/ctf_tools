<pre>
<?php
passthru("git pull");

