#! /bin/sh

$1 $2
$1 $2 "param1 param2" param3
