#!/bin/sh
echo $var
