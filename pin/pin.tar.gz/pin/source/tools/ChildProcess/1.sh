#!/bin/sh
export var=SUCCESS
$SHELL ./2.sh
