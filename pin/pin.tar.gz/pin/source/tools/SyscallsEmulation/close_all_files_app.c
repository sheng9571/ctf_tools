/*BEGIN_LEGAL 
Intel Open Source License 

Copyright (c) 2002-2018 Intel Corporation. All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.  Redistributions
in binary form must reproduce the above copyright notice, this list of
conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.  Neither the name of
the Intel Corporation nor the names of its contributors may be used to
endorse or promote products derived from this software without
specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE INTEL OR
ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
END_LEGAL */
/*! @file
* This file together with tool and makefile checks that Pin guards the file descriptors opened by itself and the
* tool (including pin.log), and doesn't let the application to close them.
*/
#ifdef NDEBUG
# undef NDEBUG
#endif
#include <assert.h>
#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <inttypes.h>

#if defined(TARGET_MAC)
const char* DIR_FD = "/dev/fd";
#elif defined(TARGET_LINUX)
const char* DIR_FD = "/proc/self/fd";
#endif

void closeAllFiles()
{
    DIR* d = opendir(DIR_FD);
    assert(NULL != d);
    struct dirent* ent;
    while (NULL != (ent = readdir(d)))
    {
        if (ent->d_name[0] == '.')
        {
            continue;
        }
        char *endptr;
        errno = 0;
        const long int fd = strtol(ent->d_name, &endptr, 10);
        if (*endptr || fd < 0 || errno)
        {
            continue;
        }
        if (fd == STDIN_FILENO || fd == STDOUT_FILENO || fd == STDERR_FILENO)
        {
            continue;
        }
        int ret;
        do
        {
            ret = close(fd);
        }
        while (ret == -1 && errno == EINTR);
        assert(0 == ret);
    }
}

int main()
{
    closeAllFiles();
    printf("Application is done\n");
    fflush(stdout);
    int pid = fork();
    if (pid != 0)
    {
        // This is just for safety, letting forked child finish before checking stuff in makefile
        sleep(1);
    }
    return 0;
}

