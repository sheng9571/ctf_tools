/*NO LEGAL*/
extern "C" void foo();

int main()
{
    foo();
    return 0;
}
